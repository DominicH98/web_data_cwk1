from django.apps import AppConfig


class ReviewprofessorConfig(AppConfig):
    name = 'reviewProfessor'
