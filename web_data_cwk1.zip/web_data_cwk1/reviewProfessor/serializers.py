from rest_framework import serializers
from reviewProfessor.models import *


class ModuleInstanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModuleInstance
        fields = "__all__"


class ProfessorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Professor
        fields = "__all__"


class ModuleSerializer(serializers.ModelSerializer):
    module = ModuleInstanceSerializer(many=True, read_only=True)

    class Meta:
        model = Module
        fields = ['module', 'module_name']


class RatingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ratings
        fields = "__all__"


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'email', 'password']
