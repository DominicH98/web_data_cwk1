from io import BytesIO

from django.contrib.auth import *
from django.contrib.sessions.models import Session
from rest_framework.decorators import api_view
from rest_framework.parsers import JSONParser

from reviewProfessor.services.register import registerService
from reviewProfessor.services.list import *
from reviewProfessor.services.login import loginService
from reviewProfessor.services.logout import logoutService
from reviewProfessor.services.average import averageService
from reviewProfessor.services.rate import rateService
from reviewProfessor.serializers import *


def List(request):
    if request.method == 'GET':
        modules = Module.objects.all()
        print("Modules: " + str(modules))

        serializer = ModuleSerializer(modules, many=True)
        new_serializer = list(serializer.data)

        for module in ModuleInstance.objects.all():
            for professor in module.professor_code.all():
                if {'professor_code': professor.professor_code, 'first_name': professor.first_name,
                                       'last_name': professor.last_name} not in new_serializer:
                    new_serializer.append({'professor_code': professor.professor_code, 'first_name': professor.first_name,
                                       'last_name': professor.last_name})

        print(new_serializer)
        return JsonResponse(new_serializer, safe=False)


def View(request):
    if request.method == 'GET':
        professors = Professor.objects.all()
        serializer = ProfessorSerializer(professors, many=True)
        new_serializer = list(serializer.data)
        profCodes = Professor.objects.values_list('professor_code')

        avgList = []
        for prof in profCodes:
            moduleInstance = ModuleInstance.objects.get(professor_code=prof)
            ratings = Ratings.objects.filter(module_code=moduleInstance.module_code,
                                             year=moduleInstance.year,
                                             semester=moduleInstance.semester).values_list('rating', flat=True)
            avg = sum(ratings)/len(ratings)
            avgList.append(avg)

        new_serializer.append(avgList)
        print(new_serializer)
        return JsonResponse(new_serializer, safe=False)


@csrf_exempt
@api_view(['POST'])
def Register(request):
    if request.method == 'POST':
        stream = BytesIO(request.body)
        data = JSONParser().parse(stream)
        print(data)
        serializer = UserSerializer(data=data)
        if serializer.is_valid():
            User.objects.create_user(
                serializer.validated_data['username'],
                serializer.validated_data['email'],
                serializer.validated_data['password']
            )
        else:
            print(serializer.is_valid())
            print(serializer.errors)
            print("The Serializer Errors ^")
            return JsonResponse(serializer.errors, status=400)
    else:
        print('Not a POST request!')
    return registerService(request)


@csrf_exempt
@api_view(['POST'])
def Login(request):
    stream = BytesIO(request.body)
    data = JSONParser().parse(stream)
    serializer = UserSerializer(data=data)
    if not serializer.is_valid():
        username = serializer.data['username']
        password = serializer.data['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            print("User is logged in")
            return loginService(request)
        else:
            return HttpResponseBadRequest('Invalid Login')
    else:
        print(serializer.is_valid())
        print(serializer.errors)
        print("The Serializer Errors ^")
        return JsonResponse(serializer.errors, status=400)


@csrf_exempt
def Logout(request):
    logout(request)
    return logoutService(request)


@csrf_exempt
def Average(request):
    if request.method == 'POST':
        stream = BytesIO(request.body)
        data = JSONParser().parse(stream)

        professor_code = data['professor_code']
        module_code = data['module_code']

        prof_name = Professor.objects.get(professor_code=professor_code)
        moduleInstance = ModuleInstance.objects.get(professor_code=professor_code, module_code=module_code)
        ratings = Ratings.objects.filter(module_code=module_code,
                                         year=moduleInstance.year,
                                         semester=moduleInstance.semester).values_list('rating', flat=True)

        avg = sum(ratings) / len(ratings)
        avgStar = "*" * int(avg)
        responseString = "The average rating for " + str(prof_name.first_name) + str(
            prof_name.last_name) + " is " + avgStar
        return HttpResponse(responseString)


@csrf_exempt
def Rate(request):
    if request.method == 'POST':
        if request.user.is_authenticated:
            userid = User.objects.get(username=request.user)
            stream = BytesIO(request.body)
            data = JSONParser().parse(stream)

            professorCode = data['professor_code']
            semester = data['semester']
            year = data['year']
            module_code = data['module_code']
            data['user_ID'] = userid.id
            moduleInstance = ModuleInstance.objects.get(professor_code=professorCode, semester=semester, year=year,
                                                        module_code=module_code)

            serializer = RatingSerializer(data=data)
            if serializer.is_valid():
                Ratings.objects.create(
                    ModuleInstance_ID=moduleInstance,
                    module_code=serializer.validated_data['module_code'],
                    year=moduleInstance.year,
                    semester=moduleInstance.semester,
                    rating=serializer.validated_data['rating'],
                    user_ID=serializer.validated_data['user_ID']
                )
            else:
                print("Data is not valid")
                print(serializer.is_valid())
                print(serializer.errors)
                print("The Serializer Errors ^")
                return JsonResponse(serializer.errors, status=400)
        else:
            return HttpResponse("Current user is not logged in")
    else:
        print('Not a POST request!')
    return rateService(request)
