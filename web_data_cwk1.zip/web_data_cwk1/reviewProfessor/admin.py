from django.contrib import admin
from reviewProfessor.models import *

admin.site.register(Professor)
admin.site.register(Module)
admin.site.register(ModuleInstance)
admin.site.register(Ratings)


