from django.db import models
from django.contrib.auth.models import User


class Professor(models.Model):
    professor_code = models.CharField(max_length=120, primary_key=True)
    first_name = models.CharField(max_length=120,)
    last_name = models.CharField(max_length=120,)

    def __str__(self):
        return self.professor_code + " " + self.first_name + " " + self.last_name


class Module(models.Model):
    module_code = models.CharField(max_length=120, primary_key=True)
    module_name = models.CharField(max_length=120)

    def __str__(self):
        return self.module_code


class ModuleInstance(models.Model):
    module_code = models.ForeignKey(Module, related_name='module', on_delete=models.CASCADE)
    professor_code = models.ManyToManyField(Professor)
    semester = models.IntegerField()
    year = models.IntegerField()


class Ratings(models.Model):
    ModuleInstance_ID = models.ForeignKey(ModuleInstance, on_delete=models.CASCADE)
    user_ID = models.ForeignKey(User, on_delete=models.CASCADE)
    module_code = models.ForeignKey(Module, on_delete=models.CASCADE, default="CD14")
    year = models.IntegerField(default=0)
    semester = models.IntegerField(default=0)
    rating = models.IntegerField()
