from django.views.decorators.csrf import csrf_exempt
from django.http import *


@csrf_exempt
def rateService(request):
    http_bad_response = HttpResponseBadRequest()
    http_bad_response['Content-Type'] = 'text/plain'

    if request.method != 'POST':
        http_bad_response.content = "Only POST Requests can be made to this service"
        return http_bad_response

    http_response = HttpResponse()
    http_response['Content-Type'] = 'application/json'
    http_response.status_code = 200
    http_response.reason_phrase = 'OK'
    return http_response
